

    <h1>Mensaje cuando el aplicativo pierde conexión a internet.</h1>
<?php /**PATH C:\laragon\www\facturacionapp\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>