</div>
<div style='border-top:1px solid #eeeeee;background:#ffffff;padding:20px;font-size:11px;color:#666'>
    <?php echo e(cbLang("email_footer")); ?>

</div>
</div><?php /**PATH C:\laragon\www\facturacionapp\vendor\crocodicstudio\crudbooster\src/views/emails/footer.blade.php ENDPATH**/ ?>