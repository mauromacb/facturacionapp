<!-- First, extends to the CRUDBooster Layout -->

<?php $__env->startSection('content'); ?>
    <!-- Your html goes here -->
    <div class='panel panel-default'>
        <div class='panel-heading'>PEDIDO #<?php echo e($pedido->secuencial_cliente); ?></div>
        <div class='panel-body'>
            <div class='form-group col-sm-12'>
                <label class="control-label col-sm-1">Fecha</label>
                <div class="col-sm-2"><?php echo e($pedido->fecha_emision); ?></div>
            </div>

            <div class='form-group col-sm-12'>
                <label class="control-label col-sm-1">Cédula/Ruc</label>
                <div class="col-sm-2"><?php echo e($pedido->cliente->identificacion); ?><?php echo e($pedido->consumidor->identificacion); ?></div>
                <label class="control-label col-sm-1">Nombres</label>
                <div class="col-sm-2"><?php echo e($pedido->cliente->nombres); ?><?php echo e($pedido->consumidor->nombres); ?></div>
                <label class="control-label col-sm-1">Teléfono</label>
                <div class="col-sm-2"><?php echo e($pedido->cliente->telefono); ?><?php echo e($pedido->consumidor->telefono); ?></div>
            </div>

            <div class='form-group col-sm-12'>
                <label class="control-label col-sm-1">Correo</label>
                <div class="col-sm-2"><?php echo e($pedido->cliente->correo); ?><?php echo e($pedido->consumidor->correo); ?></div>
                <label class="control-label col-sm-1">Dirección</label>
                <div class="col-sm-4"><?php echo e($pedido->cliente->direccion); ?><?php echo e($pedido->consumidor->direccion); ?></div>
            </div>

            <div class='form-group col-sm-12'>
                <div class="col-md-12 pre-scrollable div-detalle-comprobante form_venta_contado form_factura_credito form_devolucion_contado form_compra_contado">
                    <table width="100%" class="table-condensed table-striped table-bordered">
                        <thead>
                        <tr>
                            <th class="text-center" >Código</th>
                            <th class="text-center">Artículo</th>
                            <th class="text-center" width="80px">Precio</th>
                            <th class="text-center" width="75px">Cantidad</th>
                            <th class="text-center" width="80px">Subtotal</th>
                            <th class="text-center" width="80px">IVA</th>
                            <th class="text-center" width="80px">Total</th>
                        </tr>
                        </thead>
                        <tbody id="">
                            <?php $__currentLoopData = $dataDetallePed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td class="text-center" ><?php echo e($detalle->producto->codigo); ?></td>
                                <td class="text-center" ><?php echo e($detalle->producto->nombre); ?></td>
                                <td class="text-center" ><?php echo e($detalle->precio_unitario); ?></td>
                                <td class="text-center" ><?php echo e($detalle->cantidad); ?></td>
                                <td class="text-center" ><?php echo e($detalle->subtotal); ?></td>
                                <td class="text-center" ><?php echo e($detalle->iva); ?></td>
                                <td class="text-center" ><?php echo e($detalle->total); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="5"></th>
                                <th class="text-center" >Subtotal</th>
                                <th class="text-center" ><?php echo e($pedido->subtotal_12); ?></th>
                            </tr>
                            <tr>
                                <th colspan="5"></th>
                                <th class="text-center" >IVA</th>
                                <th class="text-center" ><?php echo e($pedido->total_iva); ?></th>
                            </tr>
                            <tr>
                                <th colspan="5"></th>
                                <th class="text-center" >Total</th>
                                <th class="text-center" ><?php echo e($pedido->total_valor); ?></th>
                            </tr>

                        </tfoot>
                    </table>
                </div>
            </div>

            <!-- etc .... -->

            </form>
        </div>

        <div class="box-footer" style="background: #F5F5F5">

            <div class="form-group">
                <div class="col-sm-10">
                        <a href='<?php echo e(url("admin/facturas/add")); ?>' class='btn btn-default'><i
                                class='fa fa-chevron-circle-left'></i> <?php echo e(cbLang("button_back")); ?></a>

                    <button class="btn btn-primary"  onclick="javascript:imprim();"><i class="fa fa-print"></i> Imprimir</button>

                </div>
            </div>


        </div>
    </div>


    <div id="muestra" style="visibility: hidden;">
        <table id="muestra" class="tabla">
            <br>
            <H1>----------------------</H1>
            <tr><th colspan="4" align="left"><?php echo e($empresa->nombre); ?></th></tr>
            <tr><td colspan="4" align="left">RUC: <?php echo e($empresa->ruc); ?></td></tr>
            <tr><td colspan="4" align="left">TELÉFONO: <?php echo e($empresa->telefono); ?></td></tr>
            <tr><td colspan="4" align="left">FACTURA: <?php echo e($pedido->secuencial); ?></td></tr>
            <tr><td colspan="4" align="left">FECHA: <?php echo e($pedido->fecha_emision); ?></td></tr>
            <tr><td colspan="4" align="left">CLIENTE: <?php echo e($pedido->cliente->nombres); ?><?php echo e($pedido->consumidor->nombres); ?></td></tr>
            <tr><td colspan="4" align="left">RUC/CED: <?php echo e($pedido->cliente->identificacion); ?><?php echo e($pedido->consumidor->identificacion); ?></td></tr>
            <tr><td colspan="4" align="left">DIRECCIÓN: <?php echo e($pedido->cliente->direccion); ?><?php echo e($pedido->consumidor->direccion); ?></td></tr>
            <tr><th>DESCRIPCIÓN</th><th>CANT</th><th>P/U</th><th>TOTAL</th></tr>
            <?php $__currentLoopData = $dataDetallePed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
                <tr>
                    <td class="text-right" align="left"><?php echo e($detalle->producto->nombre); ?></td>
                    <td class="text-right" align="center"><?php echo e($detalle->cantidad); ?></td>
                    <td class="text-right" align="center"><?php echo e($detalle->precio_unitario); ?></td>
                    <td class="text-right" align="center"><?php echo e($detalle->subtotal); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td colspan="3" >TARIFA 12%</td><td align="center"><?php echo e($pedido->subtotal_12); ?></td></tr>
            <tr><td colspan="3" >TARIFA 0%</td><td align="center"><?php echo e($pedido->subtotal_0); ?></td></tr>
            <tr><td colspan="3" >DESCUENTO</td><td align="center">0</td></tr>
            <tr><td colspan="3" >IVA 12%</td><td align="center"><?php echo e($pedido->total_iva); ?></td></tr>
            <tr><td colspan="3" >TOTAL</td><td align="center"><?php echo e($pedido->total_valor); ?></td></tr>

        </table> <center>
        <h3>GRACIAS POR SU COMPRA...</h3></center>
        <H1>----------------------</H1>
    </div>

    <script>
        function imprim(){
            var mywindow = window.open('', 'PRINT', 'width=600');
            mywindow.document.write('<html><head>');
            mywindow.document.write('');
            mywindow.document.write('</head><body >');
            mywindow.document.write(document.getElementById('muestra').innerHTML);
            mywindow.document.write('</body></html>');
            mywindow.document.close(); // necesario para IE >= 10
            mywindow.focus(); // necesario para IE >= 10
            mywindow.print();
            mywindow.close();
            return true;}
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacionapp\resources\views//verPedido.blade.php ENDPATH**/ ?>