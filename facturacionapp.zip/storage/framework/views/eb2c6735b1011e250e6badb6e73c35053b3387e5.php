<?php echo $__env->make("crudbooster::emails.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $content; ?>


<?php echo $__env->make("crudbooster::emails.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\facturacionapp\vendor\crocodicstudio\crudbooster\src/views/emails/blank.blade.php ENDPATH**/ ?>