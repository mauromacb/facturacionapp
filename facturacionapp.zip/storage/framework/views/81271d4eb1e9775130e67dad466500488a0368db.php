<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(cbLang("page_title_forgot")); ?> : <?php echo e($appname); ?></title>
    <meta name='generator' content='CRUDBooster.com'/>
    <meta name='robots' content='noindex,nofollow'/>
    <link rel="shortcut icon"
          href="<?php echo e(CRUDBooster::getSetting('favicon')?asset(CRUDBooster::getSetting('favicon')):asset('vendor/crudbooster/assets/logo_crudbooster.png')); ?>">
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="<?php echo e(asset('vendor/crudbooster/assets/adminlte/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style -->
    <link href="<?php echo e(asset('vendor/crudbooster/assets/adminlte/dist/css/AdminLTE.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <link rel='stylesheet' href='<?php echo e(asset("vendor/crudbooster/assets/css/main.css")); ?>'/>
    <link rel='stylesheet' href='<?php echo e(asset("vendor/crudbooster/assets/css/main.css")); ?>'/>
    <style type="text/css">
        .login-page, .register-page {
            background: <?php echo e(CRUDBooster::getSetting("login_background_color")?:'#dddddd'); ?> url('<?php echo e(CRUDBooster::getSetting("login_background_image")?asset(CRUDBooster::getSetting("login_background_image")):asset('vendor/crudbooster/assets/bg_blur3.jpg')); ?>');
            color: <?php echo e(CRUDBooster::getSetting("login_font_color")?:'#ffffff'); ?>  !important;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }

        .login-box-body {
            box-shadow: 0px 0px 50px rgba(0, 0, 0, 0.8);
            background: rgba(255, 255, 255, 0.9);
            color: <?php echo e(CRUDBooster::getSetting("login_font_color")?:'#666666'); ?>  !important;
        }
    </style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>
    <script src="<?php echo e(asset('js/forms/comprobantes.js')); ?>"></script>


</head>
<body class="login-page">
<div class="login-box" style="width: 570px">

    <div class="login-box-body col-sm-12" style="padding: 10px">

        <?php if( Session::get('message') != '' ): ?>
            <div class='alert alert-warning'>
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>

        <p class="login-box-msg">Ingresa la siguiente información para el registro.</p>
            <form  method="post" id="formNuevoRegistro" enctype="multipart/form-data" action="<?php echo e(url('facturas/registrar/cliente')); ?>" >
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                <div class="box-body" id="parent-form-area">
                        <div class="form-group header-group-0 col-sm-12" id="form-group-tipo" style="">
                            <label class="control-label col-sm-3">Tipo
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>

                            <div class="col-sm-8">
                                <select class="form-control" id="tipo" data-value="" required="" placeholder="Ingrese el tipo" name="tipo" onchange="getIdentificacion(this)">
                                    <option value="">** Selecciona un Tipo</option>
                                    <option value="1">Cédula</option>
                                    <option value="2">Ruc</option>
                                    <option value="3">Pasaporte</option>
                                </select>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>
                            </div>
                        </div>
                        <div class="form-group header-group-0 col-sm-12" id="form-group-identificacion" style="">
                            <label class="control-label col-sm-3">
                                Identificación
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>

                            <div class="col-sm-8">
                                <input type="text" title="Identificación" required="" placeholder="Ingrese la idenfificación" minlength="10" class="form-control" name="identificacion2" id="identificacion2" value="" onkeypress="return soloNumeros(event)">

                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 col-sm-12" id="form-group-nombres" style="">
                            <label class="control-label col-sm-3">
                                Nombres
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>

                            <div class="col-sm-8">
                                <input type="text" title="Nombres" required="" placeholder="Ingrese el nombre" maxlength="255" class="form-control" name="nombres" id="nombres" value="">

                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 col-sm-12" id="form-group-correo" style="">
                            <label class="control-label col-sm-3">Correo
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>

                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                    <input type="email" name="correo" style="display: none">
                                    <input type="email" title="Correo" required="" placeholder="Ingrese el correo" maxlength="255" class="form-control" name="correo" id="correo" value="">
                                </div>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>
                            </div>
                        </div>
                        <div class="form-group header-group-0 col-sm-12" id="form-group-telefono" style="">
                            <label class="control-label col-sm-3">Teléfono
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>

                            <div class="col-sm-8">
                                <input type="number" step="1" title="Teléfono" required="" placeholder="Ingrese el teléfono" minlength="2" class="form-control" name="telefono" id="telefono" value="">
                                <div class="text-danger"></div>
                                <p class="help-block"></p>
                            </div>
                        </div>
                        <div class="form-group header-group-0 col-sm-12" id="form-group-direccion" style="">
                            <label class="control-label col-sm-3">Dirección
                                <span class="text-danger" title="Este campo es requerido">*</span>
                            </label>
                            <div class="col-sm-8">
                                <input type="text" name="direccion" id="direccion" required="" placeholder="Ingrese la direccion" class="form-control" >
                                <div class="text-danger"></div>
                                <p class="help-block"></p>
                            </div>
                        </div>                                            </div>
                <div class="box-footer" style="background: #F5F5F5">
                    <div class="form-group">
                        <label class="control-label col-sm-2"></label>
                        <div class="col-sm-10">
                            <a href="<?php echo e(url('admin/login')); ?>" class="btn btn-default"><i class="fa fa-chevron-circle-left"></i> Volver</a>

                            <input type="submit" name="submit" value="Guardar" class="btn btn-success">

                        </div>
                    </div>
                </div><!-- /.box-footer-->
            </form>
        <br/>
        <!--a href="#">I forgot my password</a-->

    </div><!-- /.login-box-body -->
</div><!-- /.login-box -->

<script type="text/javascript">
    $("#formNuevoRegistro").validate({

        rules:{

            tipo:{
                required:true
            },
            identificacion2:{
                required:true
            },
            nombres:{
                required:true
            },
            correo:{
                required:true
            },
            telefono:{
                required:true,
                digits:true,
                maxlength:10,
                minlength:10
            },
            direccion:{
                required:true
            }
        },
        messages:{

            tipo:{
                required:"Ingrese el  tipo porfavor"
            },
            identificacion2:{
                required:"Ingrese la identificación porfavor"
            },
            nombres:{
                required:"Ingrese el nombre porfavor"
            },
            correo:{
                required:"Ingrese el correo porfavor"
            },
            telefono:{
                required:"Por favor  ingrese el telefono",
                digits:"El telefono debe tener 10 numeros",
                maxlength:"El telefono debe teber maximo 10 digitos",
                minlength:"El telefono debe tener minimo 10 digitos"
            },
            direccion:{
                required:"Ingrese la dirección porfavor"
            }

        }
    });

</script>
</body>
</html>
<?php /**PATH C:\laragon\www\facturacionapp\vendor\crocodicstudio\crudbooster\src/views/register.blade.php ENDPATH**/ ?>