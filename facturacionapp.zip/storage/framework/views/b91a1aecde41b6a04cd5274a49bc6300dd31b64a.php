

<?php $__env->startSection('content'); ?>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">

        var buscar_cliente_url = "<?php echo e(url('clientes/buscar?texto=')); ?>";
        var buscar_prodcto_url = "<?php echo e(url('productos/buscar?texto=')); ?>";
        var comprobante_vistaprevia_url = "<?php echo e(url('comprobantes/vistaPrevia')); ?>";
    </script>
    <script src="<?php echo e(asset('js/forms/comprobantes.js')); ?>"></script>

    <div>

        <?php if(CRUDBooster::getCurrentMethod() != 'getProfile' && $button_cancel): ?>
            <?php if(g('return_url')): ?>
                <p><a title='Return' href='<?php echo e(g("return_url")); ?>'><i class='fa fa-chevron-circle-left '></i>
                        &nbsp; <?php echo e(cbLang("form_back_to_list",['module'=>CRUDBooster::getCurrentModule()->name])); ?></a></p>
            <?php else: ?>
                <p><a title='Main Module' href='<?php echo e(CRUDBooster::mainpath()); ?>'><i class='fa fa-chevron-circle-left '></i>
                        &nbsp; <?php echo e(cbLang("form_back_to_list",['module'=>CRUDBooster::getCurrentModule()->name])); ?></a></p>
            <?php endif; ?>
        <?php endif; ?>

        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><i class='<?php echo e(CRUDBooster::getCurrentModule()->icon); ?>'></i> <?php echo $page_title; ?></strong>
            </div>

            <div class="panel-body" style="padding:20px 0px 0px 0px">
                <?php
                $action = (@$row) ? CRUDBooster::mainpath("edit-save/$row->id") : CRUDBooster::mainpath("add-save");
                $return_url = ($return_url) ?: g('return_url');
                ?>

                    <form class='form-horizontal' method='post' id="formNuevoComprobante" enctype="multipart/form-data" action='<?php echo e($action); ?>'>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type='hidden' name='return_url' value='<?php echo e(@$return_url); ?>'/>
                        <input type='hidden' name='ref_mainpath' value='<?php echo e(CRUDBooster::mainpath()); ?>'/>
                        <input type='hidden' name='ref_parameter' value='<?php echo e(urldecode(http_build_query(@$_GET))); ?>'/>
                        <?php if($hide_form): ?>
                            <input type="hidden" name="hide_form" value='<?php echo serialize($hide_form); ?>'>
                        <?php endif; ?>
                        <div class="modal-body">
                            <div class="box-body" id="parent-form-area">

                                <div class="form-group header-group-0 col-sm-12" id="form-group-tipo" style="">
                                    <label class="control-label col-sm-3">Tipo
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>

                                    <div class="col-sm-8">
                                        <select class="form-control" id="tipo" data-value="" required="" placeholder="Ingrese el tipo" name="tipo" onchange="getIdentificacion(this)">
                                            <option value="">** Selecciona un Tipo</option>
                                            <?php $__currentLoopData = $tipo_documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombres); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>
                                    </div>
                                </div>
                                <div class="form-group header-group-0 col-sm-12" id="form-group-identificacion" style="">
                                    <label class="control-label col-sm-3">
                                        Identificación
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>

                                    <div class="col-sm-8">
                                        <input type="text" title="Identificación" required="" placeholder="Ingrese la idenfificación" minlength="10" class="form-control" name="identificacion2" id="identificacion2" value="" onKeyPress="return soloNumeros(event)" >

                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>

                                    </div>
                                </div>
                                <div class="form-group header-group-0 col-sm-12" id="form-group-nombres" style="">
                                    <label class="control-label col-sm-3">
                                        Nombres
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>

                                    <div class="col-sm-8">
                                        <input type="text" title="Nombres" required="" placeholder="Ingrese el nombre" maxlength="255" class="form-control" name="nombres" id="nombres" value="">

                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>

                                    </div>
                                </div>
                                <div class="form-group header-group-0 col-sm-12" id="form-group-correo" style="">
                                    <label class="control-label col-sm-3">Correo
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>

                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                            <input type="email" name="correo" style="display: none">
                                            <input type="email" title="Correo" required="" placeholder="Ingrese el correo" maxlength="255" class="form-control" name="correo" id="correo" value="">
                                        </div>
                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>
                                    </div>
                                </div>
                                <div class="form-group header-group-0 col-sm-12" id="form-group-telefono" style="">
                                    <label class="control-label col-sm-3">Teléfono
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>

                                    <div class="col-sm-8">
                                        <input type="number" step="1" title="Teléfono" required="" placeholder="Ingrese el teléfono" minlength="2" class="form-control" name="telefono" id="telefono" value="">
                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>
                                    </div>
                                </div>
                                <div class="form-group header-group-0 col-sm-12" id="form-group-direccion" style="">
                                    <label class="control-label col-sm-3">Dirección
                                        <span class="text-danger" title="Este campo es requerido">*</span>
                                    </label>
                                    <div class="col-sm-8">
                                        <textarea name="direccion" id="direccion" required="" placeholder="Ingrese el teléfono" maxlength="255"  class="form-control" rows="5"></textarea>
                                        <div class="text-danger"></div>
                                        <p class="help-block"></p>
                                    </div>
                                </div>                                            </div>
                        </div>

                    <div class="box-footer" style="background: #F5F5F5">

                        <div class="form-group">
                            <label class="control-label col-sm-2"></label>
                            <div class="col-sm-10">
                                <?php if($button_cancel && CRUDBooster::getCurrentMethod() != 'getDetail'): ?>
                                    <?php if(g('return_url')): ?>
                                        <a href='<?php echo e(g("return_url")); ?>' class='btn btn-default'><i
                                                class='fa fa-chevron-circle-left'></i> <?php echo e(cbLang("button_back")); ?></a>
                                    <?php else: ?>
                                        <a href='<?php echo e(CRUDBooster::mainpath("?".http_build_query(@$_GET))); ?>' class='btn btn-default'><i
                                                class='fa fa-chevron-circle-left'></i> <?php echo e(cbLang("button_back")); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if(CRUDBooster::isCreate() || CRUDBooster::isUpdate()): ?>

                                    <?php if(CRUDBooster::isCreate() && $button_addmore==TRUE && $command == 'add'): ?>
                                        <input type="submit" name="submit" value='<?php echo e(cbLang("button_save_more")); ?>' class='btn btn-success'>
                                    <?php endif; ?>

                                    <?php if($button_save && $command != 'detail'): ?>
                                        <input type="submit" name="submit" value='<?php echo e(cbLang("button_save")); ?>' class='btn btn-success'>
                                    <?php endif; ?>

                                <?php endif; ?>
                            </div>
                        </div>


                    </div><!-- /.box-footer-->
                    </form>

            </div>


        </div>
    </div><!--END AUTO MARGIN-->

    <script type="text/javascript">
    $("#formNuevoComprobante").validate({

        rules:{

          tipo:{
            required:true
          },
          identificacion2:{
            required:true
          },
          nombres:{
            required:true
          },
          correo:{
            required:true
          },
          telefono:{
            required:true,
            digits:true,
            maxlength:10,
            minlength:10
          },
          direccion:{
            required:true
          }
        },
        messages:{

          tipo:{
            required:"Ingrese el  tipo porfavor"
          },
          identificacion2:{
            required:"Ingrese la identificación porfavor"
          },
          nombres:{
            required:"Ingrese el nombre porfavor"
          },
          correo:{
            required:"Ingrese el correo porfavor"
          },
          telefono:{
            required:"Por favor  ingrese el telefono",
            digits:"El telefono debe tener 10 numeros",
            maxlength:"El telefono debe teber maximo 10 digitos",
            minlength:"El telefono debe tener minimo 10 digitos"
          },
          direccion:{
            required:"Ingrese la dirección porfavor"
          }

        }
      });

        </script>
<style media="screen">
    .error{
      color:red;
      font-size: 16px;
    }
    input.error, select.error{
      border: 2px solid red;
    }
</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacionapp\resources\views/clientes.blade.php ENDPATH**/ ?>