<!-- First, extends to the CRUDBooster Layout -->

<?php $__env->startSection('content'); ?>
    <!-- Your html goes here -->
    <div class='panel panel-default'>
        <div class='panel-heading'>CATALOGO DE PRODUCTOS</div>
            <div class='panel-body'>
                <div class='form-group col-sm-12'>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group panel panel-default col-sm-3">
                                    <div class="panel-heading">
                                        <h3 class="panel-title"><?php echo e($detalle->nombre); ?></h3>
                                    </div>
                                    <div class="panel-body">
                                        <p class="card-text"><?php echo e($detalle->codigo); ?></p>
                                        <?php if(empty($detalle->imagen)): ?>
                                            <img class="img-responsive" src="<?php echo e(url('vendor/crudbooster/avatar.jpg')); ?>">
                                        <?php else: ?>
                                            <img class="img-responsive" src="<?php echo e(url($detalle->imagen)); ?>">
                                        <?php endif; ?>
                                        <p class="card-text"><?php echo e($detalle->stock); ?> unidades</p>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- etc .... -->
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\facturacionapp\resources\views/catalogo.blade.php ENDPATH**/ ?>